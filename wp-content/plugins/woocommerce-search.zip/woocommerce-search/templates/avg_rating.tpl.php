<div class="wcsearch-rating">
	<div class="wcsearch-rating-stars">
		<label class="wcsearch-rating-icon wcsearch-fa <?php echo wcsearch_render_star(5, $value); ?>" style="color: <?php echo esc_attr($stars_color); ?>"></label>
		<label class="wcsearch-rating-icon wcsearch-fa <?php echo wcsearch_render_star(4, $value); ?>" style="color: <?php echo esc_attr($stars_color); ?>"></label>
		<label class="wcsearch-rating-icon wcsearch-fa <?php echo wcsearch_render_star(3, $value); ?>" style="color: <?php echo esc_attr($stars_color); ?>"></label>
		<label class="wcsearch-rating-icon wcsearch-fa <?php echo wcsearch_render_star(2, $value); ?>" style="color: <?php echo esc_attr($stars_color); ?>"></label>
		<label class="wcsearch-rating-icon wcsearch-fa <?php echo wcsearch_render_star(1, $value); ?>" style="color: <?php echo esc_attr($stars_color); ?>"></label>
	</div>
</div>