<div class="wcsearch-search-model-input" <?php echo $search_model->getOptionsString(); ?>>
	<span class="wcsearch-search-model-input-reset-button wcsearch-btn wcsearch-btn-default"><?php echo esc_html($text); ?></span>
</div>