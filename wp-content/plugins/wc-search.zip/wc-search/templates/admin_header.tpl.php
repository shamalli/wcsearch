<div class="wrap">
	<?php wcsearch_renderMessages(); ?>
	