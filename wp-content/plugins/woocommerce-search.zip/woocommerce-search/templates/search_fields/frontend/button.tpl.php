<div class="wcsearch-search-input" <?php echo $search_model->getOptionsString(); ?>>
	<input type="submit" class="wcsearch-search-input-button wcsearch-btn wcsearch-btn-primary" value="<?php echo esc_attr($text); ?>" />
</div>