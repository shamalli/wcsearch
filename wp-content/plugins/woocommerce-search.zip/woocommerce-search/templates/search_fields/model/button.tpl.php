<div class="wcsearch-search-model-input" <?php echo $search_model->getOptionsString(); ?>>
	<span class="wcsearch-search-model-input-button wcsearch-btn wcsearch-btn-primary"><?php echo esc_html($text); ?></span>
</div>