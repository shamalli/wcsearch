<div class="wcsearch-search-input" <?php echo $search_model->getOptionsString(); ?>>
	<input type="button" class="wcsearch-search-input-reset-button wcsearch-btn wcsearch-btn-primary" value="<?php echo esc_html($text); ?>" />
</div>